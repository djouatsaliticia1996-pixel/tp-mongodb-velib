# TP MongoDB avec Navicat : données Vélib'

Traitement des données Vélib' en temps réel (1 519 stations) dans **Navicat Premium**, avec une connexion **MongoDB**.

## Contenu du dépôt

| Fichier | Description |
|---|---|
| `donnees/velib-disponibilite-en-temps-reel.json` | Données sources |
| `requetes_mongodb.js` | Toutes les requêtes exécutées |
| `resultat_par_commune.csv` | Résultat de l'agrégation (s'ouvre dans Excel) |
| `captures/` | Captures d'écran de Navicat |

## Étape 1 : import des données

- Connexion MongoDB (`localhost:27017`) et création de la base `Velib`.
- Import du fichier JSON avec l'**Import Wizard** de Navicat.
- Renommage de la collection en `stations`.

## Étape 2 : nettoyage des données

Vérification, puis suppression des stations hors service ou sans capacité :

```js
db.stations.find({ $or: [ { is_renting: "NON" }, { capacity: 0 } ] })
db.stations.deleteMany({ $or: [ { is_renting: "NON" }, { capacity: 0 } ] })
```

Résultat : 67 stations supprimées, il en reste 1 452.

## Étape 3 : agrégation par commune

```js
db.stations.aggregate([
  { $group: {
      _id: "$nom_arrondissement_communes",
      nb_stations: { $sum: 1 },
      velos_dispo: { $sum: "$numbikesavailable" },
      velos_electriques: { $sum: "$ebike" }
  }},
  { $sort: { velos_dispo: -1 } }
])
```

![Résultat de l'agrégation dans Navicat](captures/3_resultat_agregation.png)

## Résultats

69 communes au total. Les trois premières :

| Commune | Stations | Vélos disponibles | Dont électriques |
|---|---:|---:|---:|
| Paris | 935 | 11 733 | 3 890 |
| Boulogne-Billancourt | 29 | 568 | 108 |
| Ivry-sur-Seine | 18 | 366 | 94 |

Le tableau complet est dans [`resultat_par_commune.csv`](resultat_par_commune.csv).

## Difficultés rencontrées

1. **Collection introuvable** : la collection portait le nom du fichier (avec des tirets), donc `db.stations` ne trouvait rien. Solution : la renommer en `stations`.
2. **`SyntaxError: expected expression, got end of script`** : seule une partie de l'agrégation était sélectionnée au moment de l'exécution. Solution : sélectionner la requête complète puis relancer.

![Erreur de sélection partielle](captures/2_erreur_selection_partielle.png)
